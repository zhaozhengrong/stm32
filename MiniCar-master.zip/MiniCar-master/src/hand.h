#ifndef __HAND_H__
#define __HAND_H__

int catch_thing(void);
int place_thing(void);
void hand_left(void);
void hand_right(void);

#endif