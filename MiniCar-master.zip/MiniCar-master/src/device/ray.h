#ifndef __RAY_H__
#define __RAY_H__


void ray_config(void);
void ray_scan(void);

#endif